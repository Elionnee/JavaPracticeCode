module appstart {
    // Requiere el m�dulo appfuncs.
    requires appfuncs;
    requires userfuncs;
    
    uses userfuncs.binaryfuncs.BinaryFuncProvider;
}