module appfuncs{
    // Exporta los paquetes appfuncs.funcsimples.
    exports appfuncs.simplefunc;
}