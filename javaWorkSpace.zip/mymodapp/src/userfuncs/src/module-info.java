module userfuncs {
	exports userfuncs.binaryfuncs;
}