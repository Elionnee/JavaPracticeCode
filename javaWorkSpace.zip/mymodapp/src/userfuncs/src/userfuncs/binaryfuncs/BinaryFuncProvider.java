package userfuncs.binaryfuncs;

public interface BinaryFuncProvider {
	public BinaryFunc get();
}
